# Traceable Policy
Traceable provides a Dataweave based policy that can help you in protecting your APIs. You can attach the Traceable policy to any API registered on the Anypoint platform for security and monitoring purpose. This policy captures request and response data (headers and body) and sends them asynchronously to Traceable Platform Agent.
The captured traces and other details can be seen in the Traceable Dashboard (https://app.traceable.ai) in the environment configured while setting up your Traceable Platform Agent. <br/><br/>
There are two ways of instrumenting this policy:
- Automated policy
- API specific policy

In case of Automated policy, this policy will get automatically attached to all apis deployed in the API Manager.

### Configuration

| Property                              | Description                                                                                                                                                                                                                            |
|---------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| TA REPORTING ENDPOINT                 | The value should be of the format: ```http://<traceable_platform_agent_host>:5442/ext_cap/v1/req_res_cap```. <br/>In case of tls configuration, please use:  ```https://<traceable_platform_agent_host>:5443/ext_cap/v1/req_res_cap``` |
| TA SERVICE NAME                       | Service name for cloudhub 2.0 apps (for cloudhub 1.0, it will be the application name itself)                                                                                                                                          |
| TA DATA CAPTURE ALLOWED CONTENT TYPES | Data types allowed for capturing                                                                                                                                                                                                       |
| TA DATA CAPTURE BODY MAX SIZE BYTES   | Maximum bytes that should be captured from the body                                                                                                                                                                                    |
| TA DATA CAPTURE HTTP BODY REQUEST     | Set to true for capturing request body                                                                                                                                                                                                 |
| TA DATA CAPTURE HTTP BODY RESPONSE    | Set to true for capturing response body                                                                                                                                                                                                |
| TA DATA CAPTURE HTTP HEADERS REQUEST  | Set to true for capturing request headers                                                                                                                                                                                              |
| TA DATA CAPTURE HTTP HEADERS RESPONSE | Set to true for capturing response headers                                                                                                                                                                                             |
| TA TLS ENABLED                        | Set to true for using TLS connection to Traceable Platform Agent                                                                                                                                                                       |
| TA DATA CAPTURE COMPRESS GZIP         | Set to true for compressing the outgoing data to Traceable Platform Agent                                                                                                                                                              |

### Attaching the policy
- #### Automated Policy
    1. Navigate to API Manager.
    2. Click on Automated Policies from the left navigation menu.
    3. Click on add automated policy in the Automated Policies page.
    4. Search for the Traceable policy. Select the appropriate policy and click on Next.
    5. Enter the different values to configure Traceable. Please configure the ```TA REPORTING ENDPOINT``` value. You can set the remaining parameters according or use the default values
    6. Click on Apply to apply the policy
- #### API Policy
     1. Navigate to API Manager.
     2. Select the API to which you wish to attach the Traceable policy.
     3. Click on the Policies option as shown below
     4. Click on Add policy
     5. Search for Traceable policy. Select the policy.
     6. Enter the different values to configure Traceable. Please configure the ```TA REPORTING ENDPOINT``` value. You can set the remaining parameters according or use the default values
     7. Click on Apply to apply the policy

### Enabling Debug logging
Add these packages in logging tab of application configuration:
- org.traceable.ai.internal

For more information, please visit: https://docs.traceable.ai/docs/mulesoft